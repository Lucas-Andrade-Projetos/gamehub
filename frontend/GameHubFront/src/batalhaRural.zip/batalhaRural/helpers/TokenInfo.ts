import { Utils } from "./Utils";
import { Token } from "../entities/Token";
import { CoordinateHelper } from "./CoordinateHelper";
import { Direction } from "../enums/Direction";
import { Axis } from "../enums/Axis";

export class TokenInfo {
    readonly baseOnePosX: number;
    readonly baseOnePosY: number;
    readonly tokenSize: number;
    readonly tokenDir: Direction;
    readonly tokenName: string;
    readonly tokenChar: string;
    // baseZeroPosX: number;
    // baseZeroPosY: number;
    // baseOneFinalPosX: number;
    // baseOneFinalPosY: number;
    // baseZeroFinalPosX: number;
    // baseZeroFinalPosY: number;

    get baseOneFinalPosX(): number {
        return CoordinateHelper.calcHorizontalFinalPosition(this.baseOnePosX, this.tokenSize, this.tokenDir);
    }

    get baseOneFinalPosY(): number {
        return CoordinateHelper.calcVerticalFinalPosition(this.baseOnePosY, this.tokenSize, this.tokenDir);
    }

    get baseZeroFinalPosX(): number {
        return Utils.toBaseZero(this.baseOneFinalPosX);
    }

    get baseZeroFinalPosY(): number {
        return Utils.toBaseZero(this.baseOneFinalPosY);
    }

    get baseZeroPosX(): number {
        return Utils.toBaseZero(this.baseOnePosX);
    }

    get baseZeroPosY(): number {
        return Utils.toBaseZero(this.baseOnePosY);
    }

    get tokenAxis(): Axis {
        if (this.tokenDir == Direction.Up || this.tokenDir == Direction.Down) { return Axis.Y; }
        else { return Axis.X; }
    }

    constructor(token: Token) {
        this.tokenSize = token.size;
        this.tokenDir = token.direction;
        this.tokenName = token.name;
        this.tokenChar = token.character;
        this.baseOnePosX = token.positionX;
        this.baseOnePosY = token.positionY;
        // this.baseOneFinalPosX = CoordinateHelper.calcHorizontalFinalPosition(this.baseOnePosX, this.tokenSize, this.tokenDir);
        // this.baseOneFinalPosY = CoordinateHelper.calcVerticalFinalPosition(this.baseOnePosY, this.tokenSize, this.tokenDir);
        // this.baseZeroPosX = Utils.toBaseZero(this.baseOnePosX);
        // this.baseZeroPosY = Utils.toBaseZero(this.baseOnePosY);
        // this.baseZeroFinalPosX = Utils.toBaseZero(this.baseOneFinalPosX);
        // this.baseZeroFinalPosY = Utils.toBaseZero(this.baseOneFinalPosY);
    }
}